Each platform should be independent from one another.

For more information about the bootloader design:
https://pebbletechnology.atlassian.net/wiki/display/DEV/Bootloader+Contract
