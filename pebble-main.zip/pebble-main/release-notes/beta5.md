* Mo' features, mo' bugfixes

