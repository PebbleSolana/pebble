Bug Fixes 
---------- 
* Fixed a problem that caused the phone app to disconnect immediately after a firmware update.
