==================================================
Tuesday May 14 22:00:00 UTC 2013

Pebble Technology is pleased to announce the release of PebbleOS v1.10.2 for the Pebble SmartWatch.

Bug Fixes
----------
* Fixed a bug in AppMessage error handling
* Fixed a crash in the alarm app
* Made minor layout tweaks to the built-in sports app
