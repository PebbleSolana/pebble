* Adds support for Pebble Steel charging indicator.

Bug Fixes 
---------- 
