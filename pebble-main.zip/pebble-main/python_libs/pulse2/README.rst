pebble.pulse2
=============

pulse2 is a Python implementation of the PULSEv2 protocol suite.

https://pebbletechnology.atlassian.net/wiki/display/DEV/PULSEv2+Protocol+Suite
