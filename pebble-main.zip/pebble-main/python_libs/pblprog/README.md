# pblprog
Utility for flashing Pebble BigBoards over SWD

Installation
------------

Install from PyPi (https://pebbletechnology.atlassian.net/wiki/display/DEV/pypi) under the package name `pebble.programmer`.


Supported devices
-----------------

It is relatively easy to add support for any STM32/SWD based Pebble BigBoard. Currently supported are:

- silk_bb
- robert_bb